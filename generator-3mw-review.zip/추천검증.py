from playwright.sync_api import sync_playwright
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=b.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.goto('http://127.0.0.1:8012/')
 assert page.input_value('#g_cap')=='3'
 checks=page.evaluate('''() => {
  S.pnu='2644010100116190000';$q('f_addr').value='부산 강서구 대저1동 1619';
  gridRender();
  if(S.gridEval.proposal.score!==10 || S.gridEval.proposal.confirmed!==false) throw Error('3MW proposal');
  if(S.gridEval.items[2].got!==null || S.gridEval.total!==null) throw Error('proposal cannot become confirmed score');
  const noData=S.gridEval.proposal;
  S.grid={pole:{poleNumber:'TEST'},row:{capacity:{feeder:{headroomKw:4000}}}};gridRender();
  if(S.gridEval.proposal.score!==10 || !S.gridEval.proposal.context.includes('전주')) throw Error('pole context');
  S.grid.row.capacity.feeder.headroomKw=2999;gridRender();if(S.gridEval.proposal.score!==null) throw Error('insufficient margin');
  S.grid.row.capacity.feeder.headroomKw=3000;gridRender();if(S.gridEval.proposal.score!==10) throw Error('margin boundary');
  S.grid.nearbyLot=true;gridRender();if(!S.gridEval.proposal.context.includes('다른 지번')) throw Error('nearby provenance');
  $q('g_volt').value='ded1';gridRender();if(S.gridEval.proposal!==null || S.gridEval.items[2].got!==6) throw Error('manual override');
  $q('g_volt').value='';$q('g_cap').value='4';gridRender();if(S.gridEval.proposal!==null) throw Error('unsupported capacity');
  $q('g_cap').value='3';connectionEvidence={source:'TEST',verifiedAt:'2026-10-01'};$q('g_volt').value='ded2';gridRender();if(S.gridEval.proposal!==null || S.gridEval.items[2].got!==3) throw Error('confirmed precedence');
  connectionEvidence=null;$q('g_volt').value='';$q('connectionStatus').textContent='자료가 서로 다릅니다';gridRender();if(S.gridEval.proposal.score!==null) throw Error('conflict');
  $q('connectionStatus').textContent='미확인';S.grid=null;gridRender();
  return {noData,confirmedScore:S.gridEval.items[2].got,total:S.gridEval.total};
}''')
 assert '확정 배점에 합산하지 않음' in page.locator('#connectionProposal').inner_text()
 page.evaluate('''() => {const report=JSON.parse(document.getElementById('keccReportSource').textContent);const d=new DOMParser().parseFromString(report,'text/html');for(const s of d.scripts)if(!s.type || s.type==='text/javascript')new Function(s.textContent);}''')
 assert not errors,errors
 print('PASS: 3MW default; proposal 10; no false confirmed score; missing data; pole/nearby provenance; capacity margin and boundary; manual/confirmed override; unsupported size; conflicts; report syntax')
 print(checks)
 b.close()
