import json,re
from pathlib import Path
from playwright.sync_api import sync_playwright
BASE='http://127.0.0.1:8012'
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':1100});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto(BASE)
 assert not errors,errors
 assert page.input_value('#g_volt')==''
 result=page.evaluate('''() => {
  const checks=[];
  const base={capMw:10,volt:'',region:'서울',sameAreaMw:0,sameSubMw:0,refKw:100000,recvKw:10000,demandPct:50};
  REGION_DATA=[['서울',10000,15000]];
  for(const [volt,score] of VOLT_OPTS.map(x=>[x[0],x[2]])) {const r=gridCalc({...base,volt}); if(r.items.find(x=>x.no==='2').got!==score || !r.complete) throw new Error(volt); checks.push(volt+':'+score);}
  const unknown=gridCalc(base); if(unknown.complete || unknown.total!==null || unknown.conv!==null || unknown.items[2].got!==null) throw new Error('unknown scored');
  if(gridCalc({...base,capMw:41}).items[2].got!==0) throw new Error('40MW');
  if(gridCalc({...base,capMw:0,volt:'lv'}).items[2].got!==null) throw new Error('zero capacity');
  if(gridCalc({...base,capMw:40,volt:'pub'}).items[2].got!==10) throw new Error('boundary');
  S.pnu='1111010100100010000';$q('g_cap').value='10';
  return checks;
}''')
 print('Score cases',result,'unknown, zero capacity, 40MW boundary, >40MW passed')
 record={'pnu':'1111010100100010000','capMw':10,'volt':'ded1','source':'TEST 접속검토 문서 <img src=x onerror=alert(1)>','verifiedAt':'2026-10-01'}
 page.locator('#connectionFile').set_input_files({'name':'connection.json','mimeType':'application/json','buffer':json.dumps([record]).encode()})
 page.wait_for_function("document.getElementById('g_volt').value==='ded1'")
 assert page.evaluate('S.gridEval.items[2].got')==6
 assert not page.locator('#gridResult img').count()
 assert page.evaluate('S.gridEval.connection.source')==record['source']
 print('JSON import -> exact parcel/capacity -> 6 points, provenance and HTML escaping passed')
 page.evaluate("S.pnu='1111010100100020000';connectionLookup()")
 page.wait_for_function("document.getElementById('connectionStatus').textContent.includes('확인 필요')")
 assert page.input_value('#g_volt')==''
 assert page.evaluate('S.gridEval.items[2].got') is None
 page.evaluate("S.pnu='1111010100100010000';$q('g_cap').value='20';connectionLookup()")
 page.wait_for_function("document.getElementById('connectionStatus').textContent.includes('확인 필요')")
 assert page.input_value('#g_volt')==''
 print('Different parcel / different project capacity cannot reuse evidence: passed')
 page.evaluate("$q('g_cap').value='10';connectionLookup()")
 page.wait_for_function("document.getElementById('g_volt').value==='ded1'")
 page.evaluate("$q('g_volt').value='pub';$q('g_volt').dispatchEvent(new Event('change'))")
 assert page.evaluate('S.gridEval.connection') is None
 assert '수동 가정' in page.locator('#gridResult').inner_text()
 print('Manual override labelled assumption: passed')
 # API result takes longer than parcel change: old request must not apply.
 page.route('**/api/grid-connection?**',lambda route:route.fulfill(json={'records':[record]}))
 page.evaluate("S.pnu='1111010100100010000';$q('g_cap').value='10';connectionLookup();S.pnu='1111010100100020000';connectionLookup()")
 page.wait_for_function("document.getElementById('connectionStatus').textContent.includes('확인 필요')")
 assert page.input_value('#g_volt')==''
 print('Asynchronous parcel change cannot apply old result: passed')
 # Monthly failure must remove prior data; no stale fallback.
 page.route('**/api/monthly-stats',lambda route:route.fulfill(status=502,json={'error':'TEST upstream unavailable'}))
 page.evaluate('refreshStatistics()')
 assert page.evaluate('REGION_DATA.length')==0
 assert page.evaluate('S.gridEval.items.find(x=>x.no==="3.1").got') is None
 print('Monthly HTTP failure clears previous values: passed')
 # Import the synthetic monthly workbook through the real upload route and UI.
 import runpy
 fixture=runpy.run_path(str(Path(__file__).with_name('검증.py')))['workbook'](True)
 page.locator('#monthlyStatsFile').set_input_files({'name':'TEST-monthly.xlsx','mimeType':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','buffer':fixture})
 page.wait_for_function("REGION_DATA.length===16")
 assert page.evaluate('REGION_META.period')=='2026-08'
 assert '최신 여부 미확인' in page.locator('#monthlyStatsStatus').inner_text()
 print('Monthly XLSX upload -> 16 regions and period -> latest status unverified: passed')
 # Check JS syntax in all inline scripts, including report iframe source.
 scripts=page.evaluate('Array.from(document.scripts).filter(s=>!s.type || s.type==="text/javascript").map(s=>s.textContent)')
 report=page.evaluate('JSON.parse(document.getElementById("keccReportSource").textContent)')
 report_scripts=re.findall(r'<script\b[^>]*>(.*?)</script>',report,re.S)
 for script in scripts+report_scripts:
  page.evaluate('(s)=>{ new Function(s); }',script)
 assert 'ev.complete ? num(Math.round(ev.total' in report
 assert '연계 방식 확인 필요 · 확정 점수 미정' in report
 page.evaluate("document.getElementById('home').style.display='none';document.getElementById('mGrid').style.display='flex'")
 page.screenshot(path=str(Path(__file__).with_name('계통평가-검증.png')),full_page=True)
 assert not errors,errors
 print('Report syntax, unknown score text, all browser checks: passed')
 b.close()
