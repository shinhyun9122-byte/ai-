import io,json,zipfile,urllib.request,urllib.error,unittest,importlib.util,os
from pathlib import Path
from xml.sax.saxutils import escape
BASE='http://127.0.0.1:8012'
spec=importlib.util.spec_from_file_location('generator',Path(__file__).with_name('server.py')); app=importlib.util.module_from_spec(spec);spec.loader.exec_module(app)
def workbook(merged=False,period='2026.08',unit='GWh'):
 regions=app._MONTHLY.REGIONS[:]
 if merged: regions=[n for n in regions if n not in ('광주','전남')]+['전남광주']
 def sheet(rows):
  return '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>'+''.join('<row>'+''.join(f'<c r="{col}{i}" t="inlineStr"><is><t>{escape(str(value))}</t></is></c>' for col,value in row.items())+'</row>' for i,row in enumerate(rows,1))+'</sheetData></worksheet>'
 gen=[{'A':'2026년 8월','B':unit},{'A':'지역','B':'계'}]+[{'A':r,'B':10} for r in regions]
 cols=[chr(66+i) for i in range(len(regions))]
 sales=[{'A':'MWh'},{'A':'구분',**dict(zip(cols,regions))},{'A':period,**{c:15000 for c in cols}}]
 b=io.BytesIO()
 with zipfile.ZipFile(b,'w') as z:
  z.writestr('xl/workbook.xml','<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="10.행정구역 발전량" sheetId="1" r:id="r1"/><sheet name="20.행정구역 판매량" sheetId="2" r:id="r2"/></sheets></workbook>')
  z.writestr('xl/_rels/workbook.xml.rels','<Relationships><Relationship Id="r1" Target="worksheets/s1.xml"/><Relationship Id="r2" Target="worksheets/s2.xml"/></Relationships>')
  z.writestr('xl/worksheets/s1.xml',sheet(gen));z.writestr('xl/worksheets/s2.xml',sheet(sales))
 return b.getvalue()
class MonthlyTests(unittest.TestCase):
 def test_monthly_units(self):
  d=app._MONTHLY.parse_monthly(workbook());self.assertEqual(d['period'],'2026-08');self.assertEqual(len(d['rows']),17);self.assertEqual(d['rows'][0][1:], [10000,15000,150,10])
 def test_merged(self):
  d=app._MONTHLY.parse_monthly(workbook(True));self.assertEqual(len(d['rows']),16);self.assertIn('전남광주',[r[0] for r in d['rows']]);self.assertNotIn('전남',[r[0] for r in d['rows']])
 def test_wrong_month_rejected(self):
  with self.assertRaises(ValueError): app._MONTHLY.parse_monthly(workbook(period='2026.07'))
 def test_unknown_units_rejected(self):
  with self.assertRaises(ValueError): app._MONTHLY.parse_monthly(workbook(unit='kWh'))
 def test_bad_zip_rejected(self):
  with self.assertRaises(zipfile.BadZipFile): app._MONTHLY.parse_monthly(b'not xlsx')
 def test_import_http(self):
  request=urllib.request.Request(BASE+'/api/monthly-stats/import',data=workbook(True),headers={'Content-Type':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'})
  with urllib.request.urlopen(request) as r: self.assertEqual(len(json.load(r)['rows']),16)
 def test_bad_import_http(self):
  with self.assertRaises(urllib.error.HTTPError) as c: urllib.request.urlopen(urllib.request.Request(BASE+'/api/monthly-stats/import',data=b'broken'))
  self.assertEqual(c.exception.code,400)
 def test_connection_endpoint(self):
  with urllib.request.urlopen(BASE+'/api/grid-connection?pnu=1111010100100010000&capMw=10') as r:self.assertEqual(json.load(r),{'records':[]})
  with self.assertRaises(urllib.error.HTTPError) as c:urllib.request.urlopen(BASE+'/api/grid-connection?pnu=bad&capMw=10')
  self.assertEqual(c.exception.code,400)
if __name__=='__main__':unittest.main(verbosity=2)
